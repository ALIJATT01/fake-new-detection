# Fake News Detection Web Application

A complete web application for detecting fake news using machine learning and Flask.

## Features

- **Machine Learning Model**: Uses Logistic Regression trained on fake/real news dataset
- **Modern UI**: Dark theme with responsive design and smooth animations
- **Real-time Analysis**: Instant prediction with confidence scores
- **Explanation System**: Provides reasons for classification
- **Error Handling**: Comprehensive input validation and error messages

## Project Structure

```
fake-news-detection/
├── app.py                    # Flask backend application
├── model.pkl                 # Trained ML model (generated)
├── Fake.csv                  # Fake news dataset
├── True.csv                  # Real news dataset
├── templates/
│   └── index.html           # Main HTML template
└── static/
    ├── style.css            # CSS styles
    └── script.js            # JavaScript functionality
```

## Installation & Setup

1. **Clone or download** the project files

2. **Install dependencies**:
   ```bash
   pip install flask pandas scikit-learn joblib
   ```

3. **Ensure data files** are present:
   - `Fake.csv` - Dataset with fake news articles
   - `True.csv` - Dataset with real news articles

4. **Run the application**:
   ```bash
   python app.py
   ```

5. **Open browser** and go to:
   ```
   http://localhost:5000
   ```

## How It Works

### Backend (Flask)
- **Data Processing**: Cleans and preprocesses news text
- **Model Training**: Trains Logistic Regression on TF-IDF features
- **Prediction**: Classifies input text as REAL or FAKE
- **Confidence**: Provides prediction confidence percentage
- **Explanation**: Generates human-readable analysis

### Frontend (HTML/CSS/JS)
- **Responsive Design**: Works on desktop and mobile
- **Dark Theme**: Modern black/blue color scheme
- **AJAX Calls**: Asynchronous prediction without page reload
- **Loading States**: Visual feedback during analysis
- **Result Display**: Clear presentation of results and explanations

## API Endpoints

### GET /
Returns the main application interface.

### POST /predict
Accepts JSON with news text and returns prediction.

**Request:**
```json
{
  "news_text": "Your news article text here..."
}
```

**Response:**
```json
{
  "final": "REAL",
  "confidence": 87.5,
  "explanation": "This article appears to be REAL news..."
}
```

## Technologies Used

- **Backend**: Python, Flask, scikit-learn, pandas, joblib
- **Frontend**: HTML5, CSS3, JavaScript (ES6), Fetch API
- **ML Model**: Logistic Regression with TF-IDF vectorization
- **Styling**: Modern CSS with gradients and animations

## Model Training

The application automatically trains the model on startup using:
- **Fake.csv** and **True.csv** datasets
- **TF-IDF Vectorization** for text features
- **Logistic Regression** classifier
- **Model Caching** for faster subsequent startups

## Usage Examples

### Real News Example
Input: "The government announced a new education policy today that will increase funding for schools by 15%."

Output: REAL (High confidence)

### Fake News Example
Input: "Scientists discover that drinking bleach cures all diseases! Experts shocked!"

Output: FAKE (High confidence)

## Customization

### Changing the Model
Edit `app.py` to use different algorithms:
```python
from sklearn.naive_bayes import MultinomialNB
model = MultinomialNB()
```

### Modifying UI Colors
Update `static/style.css` variables for different themes.

### Adding Features
Extend the Flask routes in `app.py` for additional functionality.

## Troubleshooting

### Model Not Loading
- Ensure `Fake.csv` and `True.csv` are in the project root
- Check file permissions
- Restart the application

### Port Already in Use
- Kill existing Flask processes
- Use different port: `app.run(port=5001)`

### Slow Startup
- Model training takes time on first run
- Subsequent runs load cached model instantly

## License

This project is open source and available under the MIT License.

## Contributing

Feel free to submit issues and enhancement requests!