from flask import Flask, render_template, request, jsonify
import pandas as pd
import re
import joblib
from sklearn.model_selection import train_test_split
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.linear_model import LogisticRegression
from sklearn.tree import DecisionTreeClassifier
from sklearn.ensemble import RandomForestClassifier
import os

app = Flask(__name__)

MODEL_CACHE = 'news_models.joblib'

vectorization = None
LR  = None
DTC = None
RFC = None
model_trained = False

# Same function as your notebook
def wordopt(text):
    text = text.lower()
    text = re.sub(r'http\S+', '', text)
    text = re.sub(r'[^a-zA-Z]', ' ', text)
    text = re.sub(r'\s+', ' ', text).strip()
    return text

def output_label(n):
    return "Fake News" if n == 0 else "Genuine News"

def train_models():
    global vectorization, LR, DTC, RFC, model_trained

    if not os.path.exists('Fake.csv') or not os.path.exists('True.csv'):
        print("ERROR: Fake.csv or True.csv not found!")
        return False

    # Load from cache if available (instant on 2nd run)
    if os.path.exists(MODEL_CACHE):
        print("Loading from cache...")
        cache = joblib.load(MODEL_CACHE)
        vectorization = cache['vectorizer']
        LR  = cache['lr']
        DTC = cache['dtc']
        RFC = cache['rfc']
        model_trained = True
        print("Loaded from cache!")
        return True

    print("Reading CSV files...")
    fake = pd.read_csv('Fake.csv')
    true = pd.read_csv('True.csv')

    true['label'] = 1
    fake['label'] = 0

    news = pd.concat([fake, true], axis=0)
    news = news.drop(['title', 'subject', 'date'], axis=1)
    news = news.sample(frac=1).reset_index(drop=True)
    news['text'] = news['text'].apply(wordopt)

    x = news['text']
    y = news['label']

    # 20% of data for fast training
    x_small, _, y_small, _ = train_test_split(x, y, test_size=0.80, random_state=42, stratify=y)
    x_train, x_test, y_train, y_test = train_test_split(x_small, y_small, test_size=0.3, random_state=42)

    print("Vectorizing text...")
    vectorization = TfidfVectorizer()
    xv_train = vectorization.fit_transform(x_train)
    xv_test  = vectorization.transform(x_test)

    print("Training Logistic Regression...")
    LR = LogisticRegression()
    LR.fit(xv_train, y_train)
    print(f"LR Accuracy: {round(LR.score(xv_test, y_test)*100, 1)}%")

    print("Training Decision Tree...")
    DTC = DecisionTreeClassifier()
    DTC.fit(xv_train, y_train)
    print(f"DTC Accuracy: {round(DTC.score(xv_test, y_test)*100, 1)}%")

    print("Training Random Forest...")
    RFC = RandomForestClassifier(n_estimators=50)
    RFC.fit(xv_train, y_train)
    print(f"RFC Accuracy: {round(RFC.score(xv_test, y_test)*100, 1)}%")

    print("Saving models to cache...")
    joblib.dump({'vectorizer': vectorization, 'lr': LR, 'dtc': DTC, 'rfc': RFC}, MODEL_CACHE)

    model_trained = True
    print("Training complete!")
    return True

print("=" * 40)
print("  Fake News Detection Server")
print("=" * 40)
success = train_models()
print("Server Ready!" if success else "WARNING: Check CSV files.")
print("=" * 40)


@app.route('/')
def index():
    return render_template('index.html')

@app.route('/status')
def status():
    return jsonify({'ready': model_trained})

@app.route('/predict', methods=['POST'])
def predict():
    if not model_trained:
        return jsonify({'error': 'Models not ready. Place Fake.csv & True.csv in project folder and restart.'})

    data = request.get_json()
    text = data.get('text', '').strip()

    if not text:
        return jsonify({'error': 'Please enter some news text.'})

    if len(text.split()) < 5:
        return jsonify({'error': 'Please enter at least a few sentences for accurate prediction.'})

    cleaned    = wordopt(text)
    vectorized = vectorization.transform([cleaned])

    lr_pred  = int(LR.predict(vectorized)[0])
    dtc_pred = int(DTC.predict(vectorized)[0])
    rfc_pred = int(RFC.predict(vectorized)[0])

    lr_conf  = float(max(LR.predict_proba(vectorized)[0]))
    dtc_conf = float(max(DTC.predict_proba(vectorized)[0]))
    rfc_conf = float(max(RFC.predict_proba(vectorized)[0]))

    votes      = lr_pred + dtc_pred + rfc_pred
    final_pred = 1 if votes >= 2 else 0
    prediction = "Real" if final_pred == 1 else "Fake"
    avg_conf   = round(((lr_conf + dtc_conf + rfc_conf) / 3) * 100, 1)

    if prediction == "Real":
        explanation = "All 3 classifiers analyzed this article. Majority voted GENUINE — the writing style and content patterns match authentic news sources."
    else:
        explanation = "All 3 classifiers analyzed this article. Majority voted FAKE — the content shows patterns commonly found in misinformation."

    return jsonify({
        'prediction':  prediction,
        'confidence':  avg_conf,
        'explanation': explanation,
        'models': {
            'Logistic Regression': {'label': output_label(lr_pred),  'confidence': round(lr_conf  * 100, 1)},
            'Decision Tree':       {'label': output_label(dtc_pred), 'confidence': round(dtc_conf * 100, 1)},
            'Random Forest':       {'label': output_label(rfc_pred), 'confidence': round(rfc_conf * 100, 1)},
        }
    })

if __name__ == '__main__':
    app.run(debug=False)
